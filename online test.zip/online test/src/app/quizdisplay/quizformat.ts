export interface Quizformat{
        qid:string;
        qtext:string;
        op1:string;
        op2:string;
        op3:string;
        op4:string;
        ans:string;
}